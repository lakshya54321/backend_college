//commonjs syntax
const mymodule=require("./Q1");

console.log(mymodule.students.course.subjects.sem1);

console.log(mymodule.greatstudent());

