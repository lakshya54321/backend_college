//using ES6 syntax
import { students, greatStudent } from "./Q1_2.mjs";

console.log(students.course.subjects.sem1);

console.log(greatStudent());
